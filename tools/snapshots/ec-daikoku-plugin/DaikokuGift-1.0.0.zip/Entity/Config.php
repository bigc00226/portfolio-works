<?php

namespace Plugin\DaikokuGift\Entity;

use Doctrine\ORM\Mapping as ORM;
use Eccube\Entity\AbstractEntity;

if (!class_exists('\Plugin\DaikokuGift\Entity\Config', false)) {
    /**
     * のし指定の設定（1 件だけ）
     *
     * @ORM\Table(name="plg_daikoku_gift_config")
     * @ORM\Entity(repositoryClass="Plugin\DaikokuGift\Repository\ConfigRepository")
     */
    class Config extends AbstractEntity
    {
        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * 注文手続きで のし指定を受け付ける
         *
         * @var bool
         *
         * @ORM\Column(name="accept", type="boolean", options={"default":true})
         */
        private $accept = true;

        /**
         * 名入れの最大文字数
         *
         * @var int
         *
         * @ORM\Column(name="name_max_length", type="smallint", options={"unsigned":true, "default":10})
         */
        private $name_max_length = 10;

        /**
         * 注文手続きの のし欄に出す案内
         *
         * @var string|null
         *
         * @ORM\Column(name="guide_text", type="string", length=255, nullable=true)
         */
        private $guide_text;

        public function getId()
        {
            return $this->id;
        }

        public function isAccept()
        {
            return $this->accept;
        }

        public function setAccept($accept)
        {
            $this->accept = (bool) $accept;

            return $this;
        }

        public function getNameMaxLength()
        {
            return $this->name_max_length;
        }

        public function setNameMaxLength($nameMaxLength)
        {
            $this->name_max_length = (int) $nameMaxLength;

            return $this;
        }

        public function getGuideText()
        {
            return $this->guide_text;
        }

        public function setGuideText($guideText)
        {
            $this->guide_text = $guideText;

            return $this;
        }
    }
}
