<?php

namespace Plugin\DaikokuGift\Entity;

use Doctrine\ORM\Mapping as ORM;
use Eccube\Annotation\EntityExtension;

/**
 * お届け先：のし（注文手続き・受注登録で入力し、受注に残す）
 *
 * @EntityExtension("Eccube\Entity\Shipping")
 */
trait ShippingTrait
{
    /**
     * のしの種類（outer：外のし / inner：内のし / null：のしなし）
     *
     * @var string|null
     *
     * @ORM\Column(name="daikoku_noshi_type", type="string", length=10, nullable=true)
     */
    private $noshi_type;

    /**
     * 表書き（選んだときの文字のまま残す）
     *
     * @var string|null
     *
     * @ORM\Column(name="daikoku_noshi_title", type="string", length=50, nullable=true)
     */
    private $noshi_title;

    /**
     * 名入れ
     *
     * @var string|null
     *
     * @ORM\Column(name="daikoku_noshi_name", type="string", length=50, nullable=true)
     */
    private $noshi_name;

    public function getNoshiType()
    {
        return $this->noshi_type;
    }

    public function setNoshiType($noshiType)
    {
        $this->noshi_type = $noshiType;

        return $this;
    }

    /**
     * 外のし / 内のし（メール・CSV 用）
     */
    public function getNoshiTypeName()
    {
        return NoshiTitle::TYPES[$this->noshi_type] ?? null;
    }

    public function getNoshiTitle()
    {
        return $this->noshi_title;
    }

    public function setNoshiTitle($noshiTitle)
    {
        $this->noshi_title = $noshiTitle;

        return $this;
    }

    public function getNoshiName()
    {
        return $this->noshi_name;
    }

    public function setNoshiName($noshiName)
    {
        $this->noshi_name = $noshiName;

        return $this;
    }
}
