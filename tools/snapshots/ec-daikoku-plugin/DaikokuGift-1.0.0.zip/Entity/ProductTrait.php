<?php

namespace Plugin\DaikokuGift\Entity;

use Doctrine\ORM\Mapping as ORM;
use Eccube\Annotation\EntityExtension;
use Eccube\Annotation\FormAppend;

/**
 * 商品：のし対応（@FormAppend で商品登録の「基本情報」に入力欄が出る）
 *
 * @EntityExtension("Eccube\Entity\Product")
 */
trait ProductTrait
{
    /**
     * @var bool
     *
     * @ORM\Column(name="daikoku_noshi_enabled", type="boolean", options={"default":false})
     * @FormAppend(
     *     auto_render=true,
     *     type="\Symfony\Component\Form\Extension\Core\Type\CheckboxType",
     *     options={
     *         "required": false,
     *         "label": "daikoku_gift.noshi_enabled"
     *     }
     * )
     */
    private $noshi_enabled = false;

    public function isNoshiEnabled()
    {
        return (bool) $this->noshi_enabled;
    }

    public function setNoshiEnabled($noshiEnabled)
    {
        $this->noshi_enabled = (bool) $noshiEnabled;

        return $this;
    }
}
