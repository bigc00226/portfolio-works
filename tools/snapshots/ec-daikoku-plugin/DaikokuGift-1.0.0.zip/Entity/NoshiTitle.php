<?php

namespace Plugin\DaikokuGift\Entity;

use Doctrine\ORM\Mapping as ORM;
use Eccube\Entity\AbstractEntity;

if (!class_exists('\Plugin\DaikokuGift\Entity\NoshiTitle', false)) {
    /**
     * のしの表書き（御歳暮・御礼 …）
     *
     * @ORM\Table(name="plg_daikoku_gift_noshi_title")
     * @ORM\Entity(repositoryClass="Plugin\DaikokuGift\Repository\NoshiTitleRepository")
     */
    class NoshiTitle extends AbstractEntity
    {
        /** のしの種類（お届け先の noshi_type） */
        public const TYPES = ['outer' => '外のし', 'inner' => '内のし'];

        /** 水引 */
        public const MIZUHIKI = ['紅白蝶結び', '紅白結び切り', '黒白結び切り', '黄白結び切り'];

        /**
         * @var int
         *
         * @ORM\Column(name="id", type="integer", options={"unsigned":true})
         * @ORM\Id
         * @ORM\GeneratedValue(strategy="IDENTITY")
         */
        private $id;

        /**
         * @var string
         *
         * @ORM\Column(name="name", type="string", length=50)
         */
        private $name;

        /**
         * @var string
         *
         * @ORM\Column(name="mizuhiki", type="string", length=20)
         */
        private $mizuhiki;

        /**
         * @var int
         *
         * @ORM\Column(name="sort_no", type="smallint", options={"unsigned":true})
         */
        private $sort_no = 0;

        /**
         * @var bool
         *
         * @ORM\Column(name="visible", type="boolean", options={"default":true})
         */
        private $visible = true;

        public function getId()
        {
            return $this->id;
        }

        public function getName()
        {
            return $this->name;
        }

        public function setName($name)
        {
            $this->name = $name;

            return $this;
        }

        public function getMizuhiki()
        {
            return $this->mizuhiki;
        }

        public function setMizuhiki($mizuhiki)
        {
            $this->mizuhiki = $mizuhiki;

            return $this;
        }

        public function getSortNo()
        {
            return $this->sort_no;
        }

        public function setSortNo($sortNo)
        {
            $this->sort_no = (int) $sortNo;

            return $this;
        }

        public function isVisible()
        {
            return $this->visible;
        }

        public function setVisible($visible)
        {
            $this->visible = (bool) $visible;

            return $this;
        }
    }
}
