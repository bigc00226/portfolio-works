<?php

namespace Plugin\DaikokuGift\Controller\Admin;

use Eccube\Controller\AbstractController;
use Plugin\DaikokuGift\Form\Type\Admin\ConfigType;
use Plugin\DaikokuGift\Repository\ConfigRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ConfigController extends AbstractController
{
    /**
     * @var ConfigRepository
     */
    protected $configRepository;

    public function __construct(ConfigRepository $configRepository)
    {
        $this->configRepository = $configRepository;
    }

    /**
     * のし・ギフト › 基本設定（プラグイン一覧の「設定」もここ）
     *
     * @Route("/%eccube_admin_route%/daikoku_gift/config", name="daikoku_gift_admin_config")
     * @Template("@DaikokuGift/admin/config.twig")
     */
    public function index(Request $request)
    {
        $Config = $this->configRepository->get();
        $form = $this->createForm(ConfigType::class, $Config);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->persist($Config);
            $this->entityManager->flush();
            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('daikoku_gift_admin_config');
        }

        return [
            'form' => $form->createView(),
        ];
    }
}
