<?php

namespace Plugin\DaikokuGift\Controller\Admin;

use Eccube\Controller\AbstractController;
use Plugin\DaikokuGift\Entity\NoshiTitle;
use Plugin\DaikokuGift\Form\Type\Admin\NoshiTitleType;
use Plugin\DaikokuGift\Repository\NoshiTitleRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Annotation\Route;

class NoshiTitleController extends AbstractController
{
    /**
     * @var NoshiTitleRepository
     */
    protected $noshiTitleRepository;

    public function __construct(NoshiTitleRepository $noshiTitleRepository)
    {
        $this->noshiTitleRepository = $noshiTitleRepository;
    }

    /**
     * のし・ギフト › 表書き一覧（登録・編集）
     *
     * @Route("/%eccube_admin_route%/daikoku_gift/noshi_title", name="daikoku_gift_admin_noshi_title")
     * @Route("/%eccube_admin_route%/daikoku_gift/noshi_title/{id}/edit", requirements={"id" = "\d+"}, name="daikoku_gift_admin_noshi_title_edit")
     * @Template("@DaikokuGift/admin/noshi_title.twig")
     */
    public function index(Request $request, $id = null)
    {
        if ($id) {
            $NoshiTitle = $this->noshiTitleRepository->find($id);
            if (!$NoshiTitle) {
                throw new NotFoundHttpException();
            }
        } else {
            $NoshiTitle = new NoshiTitle();
            $NoshiTitle->setSortNo($this->noshiTitleRepository->count([]) + 1);
        }

        $form = $this->createForm(NoshiTitleType::class, $NoshiTitle);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->persist($NoshiTitle);
            $this->entityManager->flush();
            $this->addSuccess('admin.common.save_complete', 'admin');

            return $this->redirectToRoute('daikoku_gift_admin_noshi_title');
        }

        return [
            'form' => $form->createView(),
            'NoshiTitle' => $NoshiTitle,
            'NoshiTitles' => $this->noshiTitleRepository->findBy([], ['sort_no' => 'ASC']),
        ];
    }

    /**
     * @Route("/%eccube_admin_route%/daikoku_gift/noshi_title/{id}/delete", requirements={"id" = "\d+"}, name="daikoku_gift_admin_noshi_title_delete", methods={"DELETE"})
     */
    public function delete(Request $request, $id)
    {
        $this->isTokenValid();
        $NoshiTitle = $this->noshiTitleRepository->find($id);
        if ($NoshiTitle) {
            $this->entityManager->remove($NoshiTitle);
            $this->entityManager->flush();
            $this->addSuccess('admin.common.delete_complete', 'admin');
        }

        return $this->redirectToRoute('daikoku_gift_admin_noshi_title');
    }
}
