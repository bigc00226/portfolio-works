<?php

namespace Plugin\DaikokuGift;

use Doctrine\ORM\EntityManagerInterface;
use Eccube\Entity\Csv;
use Eccube\Entity\Master\CsvType;
use Eccube\Entity\Shipping;
use Eccube\Plugin\AbstractPluginManager;
use Plugin\DaikokuGift\Entity\Config;
use Plugin\DaikokuGift\Entity\NoshiTitle;
use Psr\Container\ContainerInterface;

class PluginManager extends AbstractPluginManager
{
    /** 表書きの初期データ [表書き, 水引] */
    private const TITLES = [
        ['御歳暮', '紅白蝶結び'],
        ['御礼', '紅白蝶結び'],
        ['御祝', '紅白蝶結び'],
        ['内祝', '紅白蝶結び'],
        ['粗品', '紅白蝶結び'],
        ['志', '黒白結び切り'],
    ];

    /** 配送CSV に足す項目 [お届け先のフィールド, 項目名] */
    private const CSV = [
        ['noshi_type_name', 'のし'],
        ['noshi_title', 'のし表書き'],
        ['noshi_name', 'のし名入れ'],
    ];

    /**
     * 有効化：設定と表書きの初期データ（初回だけ）
     */
    public function enable(array $meta, ContainerInterface $container)
    {
        $em = $container->get('doctrine')->getManager();

        if (!$em->find(Config::class, 1)) {
            $em->persist(new Config());
        }
        if ($em->getRepository(NoshiTitle::class)->count([]) === 0) {
            foreach (self::TITLES as $i => [$name, $mizuhiki]) {
                $NoshiTitle = new NoshiTitle();
                $NoshiTitle->setName($name)->setMizuhiki($mizuhiki)->setSortNo($i + 1);
                $em->persist($NoshiTitle);
            }
        }
        $em->flush();
        $this->addCsv($em);
    }

    /**
     * 無効化：配送CSV の項目を外す（お届け先の のし の列とデータは残る）
     */
    public function disable(array $meta, ContainerInterface $container)
    {
        $this->removeCsv($container->get('doctrine')->getManager());
    }

    /**
     * 削除：配送CSV の項目を外す（プラグインのテーブルは EC-CUBE が削除する）
     */
    public function uninstall(array $meta, ContainerInterface $container)
    {
        $this->removeCsv($container->get('doctrine')->getManager());
    }

    private function addCsv(EntityManagerInterface $em)
    {
        $CsvType = $em->find(CsvType::class, CsvType::CSV_TYPE_SHIPPING);
        $sortNo = (int) $em->createQuery('SELECT MAX(c.sort_no) FROM Eccube\Entity\Csv c WHERE c.CsvType = :type')
            ->setParameter('type', $CsvType)
            ->getSingleScalarResult();

        foreach (self::CSV as [$field, $label]) {
            if ($em->getRepository(Csv::class)->findOneBy(['CsvType' => $CsvType, 'field_name' => $field])) {
                continue;
            }
            $Csv = new Csv();
            $Csv->setCsvType($CsvType)
                ->setEntityName(Shipping::class)
                ->setFieldName($field)
                ->setDispName($label)
                ->setEnabled(true)
                ->setSortNo(++$sortNo)
                ->setCreateDate(new \DateTime())
                ->setUpdateDate(new \DateTime());
            $em->persist($Csv);
        }
        $em->flush();
    }

    private function removeCsv(EntityManagerInterface $em)
    {
        $CsvType = $em->find(CsvType::class, CsvType::CSV_TYPE_SHIPPING);
        foreach (self::CSV as [$field]) {
            $Csv = $em->getRepository(Csv::class)->findOneBy(['CsvType' => $CsvType, 'field_name' => $field]);
            if ($Csv) {
                $em->remove($Csv);
            }
        }
        $em->flush();
    }
}
