<?php

namespace Plugin\DaikokuGift\Form\Type\Admin;

use Eccube\Form\Type\ToggleSwitchType;
use Plugin\DaikokuGift\Entity\NoshiTitle;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class NoshiTitleType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', TextType::class, [
                'constraints' => [
                    new NotBlank(),
                    new Length(['max' => 50]),
                ],
            ])
            ->add('mizuhiki', ChoiceType::class, [
                'choices' => array_combine(NoshiTitle::MIZUHIKI, NoshiTitle::MIZUHIKI),
            ])
            ->add('visible', ToggleSwitchType::class);
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => NoshiTitle::class,
        ]);
    }
}
