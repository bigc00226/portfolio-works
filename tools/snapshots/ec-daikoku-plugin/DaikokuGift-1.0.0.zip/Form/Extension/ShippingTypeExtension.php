<?php

namespace Plugin\DaikokuGift\Form\Extension;

use Eccube\Entity\Shipping;
use Eccube\Form\Type\Admin\ShippingType as AdminShippingType;
use Eccube\Form\Type\Shopping\ShippingType;
use Plugin\DaikokuGift\Entity\NoshiTitle;
use Plugin\DaikokuGift\Repository\ConfigRepository;
use Plugin\DaikokuGift\Repository\NoshiTitleRepository;
use Symfony\Component\Form\AbstractTypeExtension;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Validator\Constraints\Length;

/**
 * お届け先のフォームに のし（種類・表書き・名入れ）
 */
class ShippingTypeExtension extends AbstractTypeExtension
{
    /**
     * @var ConfigRepository
     */
    protected $configRepository;

    /**
     * @var NoshiTitleRepository
     */
    protected $noshiTitleRepository;

    public function __construct(ConfigRepository $configRepository, NoshiTitleRepository $noshiTitleRepository)
    {
        $this->configRepository = $configRepository;
        $this->noshiTitleRepository = $noshiTitleRepository;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $Config = $this->configRepository->get();

        $builder
            ->add('noshi_type', ChoiceType::class, [
                'required' => false,
                'placeholder' => 'daikoku_gift.noshi_type.none',
                'choices' => array_flip(NoshiTitle::TYPES),
            ])
            ->add('noshi_title', ChoiceType::class, [
                'required' => false,
                'placeholder' => 'daikoku_gift.noshi_title.placeholder',
                'choices' => $this->noshiTitleRepository->getChoices(),
            ])
            ->add('noshi_name', TextType::class, [
                'required' => false,
                'constraints' => [
                    new Length(['max' => $Config->getNameMaxLength()]),
                ],
            ])
            ->addEventListener(FormEvents::POST_SUBMIT, function (FormEvent $event) {
                /** @var Shipping $Shipping */
                $Shipping = $event->getData();
                if (!$Shipping->getNoshiType()) {
                    // のしなし：表書き・名入れは残さない
                    $Shipping->setNoshiTitle(null)->setNoshiName(null);
                } elseif (!$Shipping->getNoshiTitle()) {
                    $event->getForm()->get('noshi_title')->addError(new FormError(trans('daikoku_gift.noshi_title.required')));
                }
            });
    }

    public static function getExtendedTypes(): iterable
    {
        yield ShippingType::class;
        yield AdminShippingType::class;
    }
}
