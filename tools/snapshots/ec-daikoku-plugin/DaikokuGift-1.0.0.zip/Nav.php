<?php

namespace Plugin\DaikokuGift;

use Eccube\Common\EccubeNav;

class Nav implements EccubeNav
{
    /**
     * 管理画面の左メニューに「のし・ギフト」
     *
     * @return array
     */
    public static function getNav()
    {
        return [
            'daikoku_gift' => [
                'name' => 'daikoku_gift.admin.nav',
                'icon' => 'fa-gift',
                'children' => [
                    'daikoku_gift_noshi_title' => [
                        'name' => 'daikoku_gift.admin.nav.noshi_title',
                        'url' => 'daikoku_gift_admin_noshi_title',
                    ],
                    'daikoku_gift_config' => [
                        'name' => 'daikoku_gift.admin.nav.config',
                        'url' => 'daikoku_gift_admin_config',
                    ],
                ],
            ],
        ];
    }
}
