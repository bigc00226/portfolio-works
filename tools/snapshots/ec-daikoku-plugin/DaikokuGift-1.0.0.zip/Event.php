<?php

namespace Plugin\DaikokuGift;

use Eccube\Event\TemplateEvent;
use Plugin\DaikokuGift\Repository\ConfigRepository;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class Event implements EventSubscriberInterface
{
    /**
     * @var ConfigRepository
     */
    protected $configRepository;

    public function __construct(ConfigRepository $configRepository)
    {
        $this->configRepository = $configRepository;
    }

    /**
     * @return array
     */
    public static function getSubscribedEvents()
    {
        return [
            'Shopping/index.twig' => 'onShoppingIndex',
            'Shopping/confirm.twig' => 'onShoppingConfirm',
            '@admin/Order/edit.twig' => 'onAdminOrderEdit',
            'Mail/order.twig' => 'onMailOrder',
        ];
    }

    /**
     * 注文手続き：お届け先ごとに「お届け時間」の下へ のし の入力欄
     */
    public function onShoppingIndex(TemplateEvent $event)
    {
        $event->setParameter('DaikokuGiftConfig', $this->configRepository->get());
        $this->insert($event, '{{ form_errors(form.Shippings[idx].DeliveryTime) }}', 3, "{{ include('@DaikokuGift/default/Shopping/noshi_form.twig') }}");
    }

    /**
     * ご注文内容のご確認：選んだ のし
     */
    public function onShoppingConfirm(TemplateEvent $event)
    {
        $this->insert($event, "{{ Order.Shippings[idx].shipping_delivery_time?: '指定なし'|trans }}", 3, "{{ include('@DaikokuGift/default/Shopping/noshi_confirm.twig') }}");
    }

    /**
     * 受注登録：お届け先の「お届け時間」の下に のし
     */
    public function onAdminOrderEdit(TemplateEvent $event)
    {
        $this->insert($event, '{{ form_errors(form.Shipping.DeliveryTime) }}', 2, "{{ include('@DaikokuGift/admin/order_noshi.twig') }}");
    }

    /**
     * 注文受付メール：お届け先ごとに「お届け時間」の次の行へ のし
     */
    public function onMailOrder(TemplateEvent $event)
    {
        $this->insert($event, "お届け時間：{{ Shipping.shipping_delivery_time|default('指定なし') }}", 0,
            "{% if Shipping.noshi_type %}\nのし：{{ Shipping.noshi_type_name }}・{{ Shipping.noshi_title }}{% if Shipping.noshi_name %}（名入れ：{{ Shipping.noshi_name }}）{% endif %}{% endif %}", '');
    }

    /**
     * テンプレートの $needle の後ろ（閉じタグ </div> を $close 個進んだ所）に $twig を差し込む
     */
    private function insert(TemplateEvent $event, $needle, $close, $twig, $glue = "\n")
    {
        $source = $event->getSource();
        $pos = strpos($source, $needle);
        if ($pos === false) {
            return; // テンプレートが変わっていたら何もしない
        }
        $pos += strlen($needle);
        for ($i = 0; $i < $close; $i++) {
            $pos = strpos($source, '</div>', $pos) + strlen('</div>');
        }
        $event->setSource(substr($source, 0, $pos).$glue.$twig.substr($source, $pos));
    }
}
