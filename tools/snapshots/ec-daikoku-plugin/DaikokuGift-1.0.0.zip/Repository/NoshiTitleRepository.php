<?php

namespace Plugin\DaikokuGift\Repository;

use Doctrine\Persistence\ManagerRegistry;
use Eccube\Repository\AbstractRepository;
use Plugin\DaikokuGift\Entity\NoshiTitle;

class NoshiTitleRepository extends AbstractRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, NoshiTitle::class);
    }

    /**
     * 注文手続きの選択肢（表示するものを並び順に）
     *
     * @return array<string, string> 表書き => 表書き
     */
    public function getChoices()
    {
        $choices = [];
        foreach ($this->findBy(['visible' => true], ['sort_no' => 'ASC']) as $NoshiTitle) {
            $choices[$NoshiTitle->getName()] = $NoshiTitle->getName();
        }

        return $choices;
    }
}
